package Ex04;

/**
 * Comparable
 */
public interface Comparable {

    String comparaNome();
}