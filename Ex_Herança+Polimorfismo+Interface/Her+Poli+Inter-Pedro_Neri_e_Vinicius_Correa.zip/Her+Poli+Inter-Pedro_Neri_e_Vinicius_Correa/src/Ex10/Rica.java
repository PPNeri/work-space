package Ex10;

/**
 * Rica
 */
public class Rica {

    
}