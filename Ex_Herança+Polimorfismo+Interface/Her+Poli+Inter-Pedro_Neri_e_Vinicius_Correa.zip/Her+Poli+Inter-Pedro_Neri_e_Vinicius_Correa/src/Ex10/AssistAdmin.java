package Ex10;

/**
 * AssistAdmin
 */
public class AssistAdmin extends Empregado{

    public AssistAdmin(String noma, int matricula) {
        super(noma, matricula);
        // TODO Auto-generated constructor stub
    }

    

   
    
}