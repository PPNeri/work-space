package Ex10;

/**
 * Pobre
 */
public class Pobre {

    
}