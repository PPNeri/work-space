package Ex10;

/**
 * Tecnico
 */
public class Tecnico extends Empregado{

    public Tecnico(String noma, int matricula) {
        super(noma, matricula);
        // TODO Auto-generated constructor stub
    }

    

    
    
}