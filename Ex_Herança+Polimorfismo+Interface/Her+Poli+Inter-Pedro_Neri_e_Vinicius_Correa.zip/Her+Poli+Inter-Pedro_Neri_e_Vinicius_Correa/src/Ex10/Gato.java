package Ex10;

/**
 * Gato
 */
public class Gato extends Animal{

    public Gato(String especie) {
        super(especie);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void emitirSom() {
        System.out.println("Miando");// TODO Auto-generated method stub
        
    }
}