package Ex10;

/**
 * Ingresso
 */
public class Ingresso {

    
}