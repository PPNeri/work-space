package Ex05;

/**
 * FormaGeometrica
 */
public interface FormaGeometrica {
    
    String nome();
    double calculaArea();
    double calculaPerimetro();
    

}