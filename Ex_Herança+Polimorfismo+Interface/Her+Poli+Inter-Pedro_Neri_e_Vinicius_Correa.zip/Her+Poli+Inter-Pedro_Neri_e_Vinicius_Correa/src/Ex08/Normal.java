package Ex08;

public class Normal extends Ingresso{
	
	public void imprimeIngressoNormal() {
		
		System.out.println("Ingresso normal --> " + imprimeValor());
	}

}
